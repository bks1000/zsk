<?php
$config->entry->create = new stdclass();
$config->entry->create->requiredFields = 'name, code, key';

$config->entry->edit = new stdclass();
$config->entry->edit->requiredFields = 'name, code, key';

$config->entry->help = 'http://www.zentao.net/book/zentaopmshelp/integration-287.html';
