$(function()
{
    $('#modulemenu .nav li[data-id=api]').addClass('active');
});
