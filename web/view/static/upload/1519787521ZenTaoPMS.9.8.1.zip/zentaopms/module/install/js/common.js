$(function(){$.ajustModalPosition('fit', $('.modal-dialog'))});
